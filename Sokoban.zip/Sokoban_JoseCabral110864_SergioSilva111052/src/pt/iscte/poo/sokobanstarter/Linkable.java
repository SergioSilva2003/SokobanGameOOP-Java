package pt.iscte.poo.sokobanstarter;

import java.util.List;

import pt.iscte.poo.utils.Point2D;

public interface Linkable {
	//Define a interação entre cada GameElement.
	public void link(Point2D p);
}
