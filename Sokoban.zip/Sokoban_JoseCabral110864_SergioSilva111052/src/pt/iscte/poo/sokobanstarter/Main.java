package pt.iscte.poo.sokobanstarter;

public class Main { //main

	public static void main(String[] args) {
		GameEngine.getInstance().start();
	}

}
